 
 
 
**********************************************************
*************  Important Instructions Follow  ************
**********************************************************
 
All files exported to: C:\\CADExport\\workspace\Altium\2025-02-01_12-51-49\2025-02-01_12-51-49
 
 
To import your new library part into Altium follow these steps:

1. After running the Ultra Librarian export for the first time,
you will need to copy the following files into an area where
they can be accessed for all future translations.  They are script
files that Altium will need to be able to find.
	a. UL_Form.dfm
	b. UL_Form.pas
	c. UL_Import.pas
	d. UL_Import.prjScr
	
2. Open Altium and choose "Run Script" from the File menu. When the
script window opens, navigate to the location of the files created
in step 1 and choose the UL_Import.prjScr file.

3. Select the UL_Form.pas file from the new project that has loaded in the
script window. This should cause a window to open asking for a *.txt file.

4. Navigate to and select the appropiate *.txt file of the desired libary.
The latest file produced with a date code if using the Ultra Librarian Free Reader
or other desktop software (for instance 2010-02-17_23-12-34.txt), or
"AltiumDesigner.txt" if using files downloaded from Ultralibrarian.com
or another online source.

5. The script will open a new Integraged Library project and import
the Ultra Librarian data into it.  When complete a message box
will pop up saying that import is done.


**************************************************************
**    !!!!!!!!!!!!!        WARNING        !!!!!!!!!!!!!     **
**************************************************************

Besure to check the documentation layer, "Mechanical 3", for important information
that may seem to be missing or have not translated properly!


*** Please Note! For some styles of components, after the component has been
exported to Altium Designer, the footprint is not visible in the main library frame.
Please navigate to the PCB Library view by clicking on the "PCB Library" tab at the
bottom left side of the main library frame. Once you are in the PCB Library view,
please double click on the footprint name (which should be in the top left quadrant
of the screen). After double clicking, the footprint should appear and you should
now be able to use this footprint in your design. ***



*** Altium 19 has a bug within the font manager so we have defaulted a font in order to
successfully finish importing the library to version 19!***

For additional information, please visit this site:
http://www.accelerated-designs.com/help/Altium_import.html

For a video tutorial, please visit:
https://youtu.be/r1tv_wz_uY0
 
 
Padstack "O1011810236200000P00200P00000" renamed to "O101181023620000"
Padstack "R1118111023600000P00200P00000" renamed to "R111811102360000"
Symbol "WB_STARTUP_VOLTAGE_SOURCE" renamed to "WB_STARTUP_VOLTA"
Symbol "WB_SOURCE_RESISTOR" renamed to "WB_SOURCE_RESIST"
Symbol "WB_PRIM_STARTUP_VOLTAGE_SOURCE" renamed to "WB_PRIM_STARTUP_"
Symbol "WB_PWL_CURRENT_LOAD" renamed to "WB_PWL_CURRENT_L"
Symbol "WB_PRIM_DC_VOLTAGE_SOURCE" renamed to "WB_PRIM_DC_VOLTA"
Symbol "WB_ALCOR_ENABLE_BLOCK" renamed to "WB_ALCOR_ENABLE_"
Symbol "WB_DIODE_SCHOTTKY" renamed to "WB_DIODE_SCHOTTK"
Symbol "WB_PWL_VOLTAGE_SOURCE" renamed to "WB_PWL_VOLTAGE_S"
Symbol "WB_PRIM_PWL_VOLTAGE_SOURCE" renamed to "WB_PRIM_PWL_VOLT"
Symbol "WB_PRIMITIVE_CAPACITOR" renamed to "WB_PRIMITIVE_CAP"
Symbol "WB_PRIMITIVE_INDUCTOR" renamed to "WB_PRIMITIVE_IND"
Symbol "WB_PRIM_AC_VOLTAGE_SOURCE" renamed to "WB_PRIM_AC_VOLTA"
Symbol "WB_PRIMITIVE_BATTERY" renamed to "WB_PRIMITIVE_BAT"
Symbol "WB_COUTX_AC_BLOCK" renamed to "WB_COUTX_AC_BLOC"
Component "WB_PRIM_DC_VOLTAGE_SOURCE" renamed to "WB_PRIM_DC_VOLTA"
Component "GRM155R71A104KA01D" renamed to "GRM155R71A104KA0"
Component "C2012C0G1H272J060AA" renamed to "C2012C0G1H272J06"
Component "C3225X7R2A225K230AB" renamed to "C3225X7R2A225K23"
The Symbol WB_CONTINUATION was missing a RefDes attribute, a refdes was created for the symbol.
The Symbol WB_CONTINUATION was missing a Type attribute, a type was created for the symbol.
The Symbol WB_CONTINUATION was missing a Value attribute, a value was created for the symbol.
The Symbol WB_BLOCK_IO was missing a RefDes attribute, a refdes was created for the symbol.
The Symbol WB_BLOCK_IO was missing a Type attribute, a type was created for the symbol.
The Symbol WB_BLOCK_IO was missing a Value attribute, a value was created for the symbol.
The Symbol WB_STARTUP_VOLTA was missing a RefDes attribute, a refdes was created for the symbol.
The Symbol WB_STARTUP_VOLTA was missing a Type attribute, a type was created for the symbol.
The Symbol WB_STARTUP_VOLTA was missing a Value attribute, a value was created for the symbol.
The Symbol WB_SOURCE_RESIST was missing a RefDes attribute, a refdes was created for the symbol.
The Symbol WB_SOURCE_RESIST was missing a Type attribute, a type was created for the symbol.
The Symbol WB_SOURCE_RESIST was missing a Value attribute, a value was created for the symbol.
The Symbol WB_PRIM_STARTUP_ was missing a RefDes attribute, a refdes was created for the symbol.
The Symbol WB_PRIM_STARTUP_ was missing a Type attribute, a type was created for the symbol.
The Symbol WB_PRIM_STARTUP_ was missing a Value attribute, a value was created for the symbol.
The Symbol WB_CURRENT_PROBE was missing a RefDes attribute, a refdes was created for the symbol.
The Symbol WB_CURRENT_PROBE was missing a Type attribute, a type was created for the symbol.
The Symbol WB_CURRENT_PROBE was missing a Value attribute, a value was created for the symbol.
The Symbol WB_PWL_CURRENT_L was missing a RefDes attribute, a refdes was created for the symbol.
The Symbol WB_PWL_CURRENT_L was missing a Type attribute, a type was created for the symbol.
The Symbol WB_PWL_CURRENT_L was missing a Value attribute, a value was created for the symbol.
The Symbol WB_COUTX_BLOCK was missing a RefDes attribute, a refdes was created for the symbol.
The Symbol WB_COUTX_BLOCK was missing a Type attribute, a type was created for the symbol.
The Symbol WB_COUTX_BLOCK was missing a Value attribute, a value was created for the symbol.
The Symbol WB_CAP_OUTPUT was missing a RefDes attribute, a refdes was created for the symbol.
The Symbol WB_CAP_OUTPUT was missing a Type attribute, a type was created for the symbol.
The Symbol WB_CAP_OUTPUT was missing a Value attribute, a value was created for the symbol.
The Symbol WB_VOLTAGE_PROBE was missing a RefDes attribute, a refdes was created for the symbol.
The Symbol WB_VOLTAGE_PROBE was missing a Type attribute, a type was created for the symbol.
The Symbol WB_VOLTAGE_PROBE was missing a Value attribute, a value was created for the symbol.
The Symbol WB_ALCOR_ENABLE_ was missing a RefDes attribute, a refdes was created for the symbol.
The Symbol WB_ALCOR_ENABLE_ was missing a Type attribute, a type was created for the symbol.
The Symbol WB_ALCOR_ENABLE_ was missing a Value attribute, a value was created for the symbol.
The Symbol WB_TPS54561 was missing a RefDes attribute, a refdes was created for the symbol.
The Symbol WB_TPS54561 was missing a Type attribute, a type was created for the symbol.
The Symbol WB_TPS54561 was missing a Value attribute, a value was created for the symbol.
The Symbol WB_ZENER_BLOCK was missing a RefDes attribute, a refdes was created for the symbol.
The Symbol WB_ZENER_BLOCK was missing a Type attribute, a type was created for the symbol.
The Symbol WB_ZENER_BLOCK was missing a Value attribute, a value was created for the symbol.
The Symbol WB_ZENER was missing a RefDes attribute, a refdes was created for the symbol.
The Symbol WB_ZENER was missing a Type attribute, a type was created for the symbol.
The Symbol WB_ZENER was missing a Value attribute, a value was created for the symbol.
The Symbol WB_PWL_VOLTAGE_S was missing a RefDes attribute, a refdes was created for the symbol.
The Symbol WB_PWL_VOLTAGE_S was missing a Type attribute, a type was created for the symbol.
The Symbol WB_PWL_VOLTAGE_S was missing a Value attribute, a value was created for the symbol.
The Symbol WB_PRIM_PWL_VOLT was missing a RefDes attribute, a refdes was created for the symbol.
The Symbol WB_PRIM_PWL_VOLT was missing a Type attribute, a type was created for the symbol.
The Symbol WB_PRIM_PWL_VOLT was missing a Value attribute, a value was created for the symbol.
The Symbol WB_LOAD_RESISTOR was missing a RefDes attribute, a refdes was created for the symbol.
The Symbol WB_LOAD_RESISTOR was missing a Type attribute, a type was created for the symbol.
The Symbol WB_LOAD_RESISTOR was missing a Value attribute, a value was created for the symbol.
The Symbol WB_PRIMITIVE_CAP was missing a RefDes attribute, a refdes was created for the symbol.
The Symbol WB_PRIMITIVE_CAP was missing a Type attribute, a type was created for the symbol.
The Symbol WB_PRIMITIVE_CAP was missing a Value attribute, a value was created for the symbol.
The Symbol WB_PRIMITIVE_IND was missing a RefDes attribute, a refdes was created for the symbol.
The Symbol WB_PRIMITIVE_IND was missing a Type attribute, a type was created for the symbol.
The Symbol WB_PRIMITIVE_IND was missing a Value attribute, a value was created for the symbol.
The Symbol WB_PRIM_AC_VOLTA was missing a RefDes attribute, a refdes was created for the symbol.
The Symbol WB_PRIM_AC_VOLTA was missing a Type attribute, a type was created for the symbol.
The Symbol WB_PRIM_AC_VOLTA was missing a Value attribute, a value was created for the symbol.
The Symbol WB_PRIMITIVE_BAT was missing a RefDes attribute, a refdes was created for the symbol.
The Symbol WB_PRIMITIVE_BAT was missing a Type attribute, a type was created for the symbol.
The Symbol WB_PRIMITIVE_BAT was missing a Value attribute, a value was created for the symbol.
The Symbol WB_COUTX_AC_BLOC was missing a RefDes attribute, a refdes was created for the symbol.
The Symbol WB_COUTX_AC_BLOC was missing a Type attribute, a type was created for the symbol.
The Symbol WB_COUTX_AC_BLOC was missing a Value attribute, a value was created for the symbol.


Ultra Librarian Gold 8.3.103 Process Report


Message - Padstack "R111811102360000" Shape(3) is a RECTANGLE with no height.
Message - Symbol "WB_CAPACITOR" has as multiple attributes named "TYPE".
One of the attributes was renamed to "TYPE_2".
Message - Component "RC0201FR-0718K7L" attribute "Datasheet URL" references text style "" that is not in the database.
The default pattern text style "H50s3" was substituted.
Message - Component "RC0201FR-0718K7L" attribute "Resistance" references text style "" that is not in the database.
The default pattern text style "H50s3" was substituted.
Message - Component "RC0201FR-0718K7L" attribute "Power" references text style "" that is not in the database.
The default pattern text style "H50s3" was substituted.
Message - Component "RC0201FR-0718K7L" attribute "Tolerance" references text style "" that is not in the database.
The default pattern text style "H50s3" was substituted.
Message - Component "CRCW0402274KFKED" attribute "Resistance" references text style "" that is not in the database.
The default pattern text style "H50s3" was substituted.
Message - Component "CRCW0402274KFKED" attribute "Power" references text style "" that is not in the database.
The default pattern text style "H50s3" was substituted.
Message - Component "CRCW0402274KFKED" attribute "Tolerance" references text style "" that is not in the database.
The default pattern text style "H50s3" was substituted.
Message - Component "16SVPG47M" attribute "Datasheet URL" references text style "" that is not in the database.
The default pattern text style "H50s3" was substituted.
Message - Component "16SVPG47M" attribute "Cap" references text style "" that is not in the database.
The default pattern text style "H50s3" was substituted.
Message - Component "16SVPG47M" attribute "ESR" references text style "" that is not in the database.
The default pattern text style "H50s3" was substituted.
Message - Component "16SVPG47M" attribute "IRMS" references text style "" that is not in the database.
The default pattern text style "H50s3" was substituted.
Message - Component "16SVPG47M" attribute "VDC" references text style "" that is not in the database.
The default pattern text style "H50s3" was substituted.
Message - Component "C1812C183J5GACTU" attribute "Datasheet URL" references text style "" that is not in the database.
The default pattern text style "H50s3" was substituted.
Message - Component "C1812C183J5GACTU" attribute "Cap" references text style "" that is not in the database.
The default pattern text style "H50s3" was substituted.
Message - Component "C1812C183J5GACTU" attribute "ESR" references text style "" that is not in the database.
The default pattern text style "H50s3" was substituted.
Message - Component "C1812C183J5GACTU" attribute "IRMS" references text style "" that is not in the database.
The default pattern text style "H50s3" was substituted.
Message - Component "C1812C183J5GACTU" attribute "VDC" references text style "" that is not in the database.
The default pattern text style "H50s3" was substituted.
Message - Component "CRCW040211K3FKED" attribute "Resistance" references text style "" that is not in the database.
The default pattern text style "H50s3" was substituted.
Message - Component "CRCW040211K3FKED" attribute "Power" references text style "" that is not in the database.
The default pattern text style "H50s3" was substituted.
Message - Component "CRCW040211K3FKED" attribute "Tolerance" references text style "" that is not in the database.
The default pattern text style "H50s3" was substituted.
Message - Component "CL21C140JBANNNC" attribute "Datasheet URL" references text style "" that is not in the database.
The default pattern text style "H50s3" was substituted.
Message - Component "CL21C140JBANNNC" attribute "Cap" references text style "" that is not in the database.
The default pattern text style "H50s3" was substituted.
Message - Component "CL21C140JBANNNC" attribute "ESR" references text style "" that is not in the database.
The default pattern text style "H50s3" was substituted.
Message - Component "CL21C140JBANNNC" attribute "IRMS" references text style "" that is not in the database.
The default pattern text style "H50s3" was substituted.
Message - Component "CL21C140JBANNNC" attribute "VDC" references text style "" that is not in the database.
The default pattern text style "H50s3" was substituted.
Message - Component "GRM155R71A104KA0" attribute "Cap" references text style "" that is not in the database.
The default pattern text style "H50s3" was substituted.
Message - Component "GRM155R71A104KA0" attribute "ESR" references text style "" that is not in the database.
The default pattern text style "H50s3" was substituted.
Message - Component "GRM155R71A104KA0" attribute "IRMS" references text style "" that is not in the database.
The default pattern text style "H50s3" was substituted.
Message - Component "GRM155R71A104KA0" attribute "VDC" references text style "" that is not in the database.
The default pattern text style "H50s3" was substituted.
Message - Component "CRCW04021K00FKED" attribute "Resistance" references text style "" that is not in the database.
The default pattern text style "H50s3" was substituted.
Message - Component "CRCW04021K00FKED" attribute "Power" references text style "" that is not in the database.
The default pattern text style "H50s3" was substituted.
Message - Component "CRCW04021K00FKED" attribute "Tolerance" references text style "" that is not in the database.
The default pattern text style "H50s3" was substituted.
Message - Component "C2012C0G1H272J06" attribute "Datasheet URL" references text style "" that is not in the database.
The default pattern text style "H50s3" was substituted.
Message - Component "C2012C0G1H272J06" attribute "Cap" references text style "" that is not in the database.
The default pattern text style "H50s3" was substituted.
Message - Component "C2012C0G1H272J06" attribute "ESR" references text style "" that is not in the database.
The default pattern text style "H50s3" was substituted.
Message - Component "C2012C0G1H272J06" attribute "IRMS" references text style "" that is not in the database.
The default pattern text style "H50s3" was substituted.
Message - Component "C2012C0G1H272J06" attribute "VDC" references text style "" that is not in the database.
The default pattern text style "H50s3" was substituted.
Message - Component "TPS54561DPRR" attribute "Datasheet URL" references text style "" that is not in the database.
The default pattern text style "H50s3" was substituted.
Message - Component "TPS54561DPRR" attribute "Frequency" references text style "" that is not in the database.
The default pattern text style "H50s3" was substituted.
Message - Component "TPS54561DPRR" attribute "Imax" references text style "" that is not in the database.
The default pattern text style "H50s3" was substituted.
Message - Component "TPS54561DPRR" attribute "Package" references text style "" that is not in the database.
The default pattern text style "H50s3" was substituted.
Message - Component "TPS54561DPRR" attribute "Mktg_Package" references text style "" that is not in the database.
The default pattern text style "H50s3" was substituted.
Message - Component "TPS54561DPRR" attribute "NSID" references text style "" that is not in the database.
The default pattern text style "H50s3" was substituted.
Message - Component "DR125-820-R" attribute "L" references text style "" that is not in the database.
The default pattern text style "H50s3" was substituted.
Message - Component "DR125-820-R" attribute "DCR" references text style "" that is not in the database.
The default pattern text style "H50s3" was substituted.
Message - Component "DR125-820-R" attribute "IDC" references text style "" that is not in the database.
The default pattern text style "H50s3" was substituted.
Message - Component "SK310A-TP" attribute "Datasheet URL" references text style "" that is not in the database.
The default pattern text style "H50s3" was substituted.
Message - Component "SK310A-TP" attribute "Io" references text style "" that is not in the database.
The default pattern text style "H50s3" was substituted.
Message - Component "SK310A-TP" attribute "VRRM" references text style "" that is not in the database.
The default pattern text style "H50s3" was substituted.
Message - Component "SK310A-TP" attribute "VFatIo" references text style "" that is not in the database.
The default pattern text style "H50s3" was substituted.
Message - Component "CRCW0402130KFKED" attribute "Resistance" references text style "" that is not in the database.
The default pattern text style "H50s3" was substituted.
Message - Component "CRCW0402130KFKED" attribute "Power" references text style "" that is not in the database.
The default pattern text style "H50s3" was substituted.
Message - Component "CRCW0402130KFKED" attribute "Tolerance" references text style "" that is not in the database.
The default pattern text style "H50s3" was substituted.
Message - Component "C3225X7R2A225K23" attribute "Datasheet URL" references text style "" that is not in the database.
The default pattern text style "H50s3" was substituted.
Message - Component "C3225X7R2A225K23" attribute "Cap" references text style "" that is not in the database.
The default pattern text style "H50s3" was substituted.
Message - Component "C3225X7R2A225K23" attribute "ESR" references text style "" that is not in the database.
The default pattern text style "H50s3" was substituted.
Message - Component "C3225X7R2A225K23" attribute "IRMS" references text style "" that is not in the database.
The default pattern text style "H50s3" was substituted.
Message - Component "C3225X7R2A225K23" attribute "VDC" references text style "" that is not in the database.
The default pattern text style "H50s3" was substituted.

TextStyle count:  24
Padstack count:   10
Pattern count:    9
Symbol count:     32
Component count:  18

Export

Warning: Symbol "WB_RESISTOR" attribute "PN" references missing text style ""
Warning: Symbol "WB_RESISTOR" attribute "DEV" references missing text style ""
Warning: Symbol "WB_RESISTOR" attribute "VAL" references missing text style ""
Warning: Symbol "WB_RESISTOR" attribute "TOL" references missing text style ""
Warning: Symbol "WB_RESISTOR" attribute "RefDes2" references missing text style ""
Warning: Symbol "WB_RESISTOR" attribute "PN" references missing text style ""
Warning: Symbol "WB_RESISTOR" attribute "DEV" references missing text style ""
Warning: Symbol "WB_RESISTOR" attribute "VAL" references missing text style ""
Warning: Symbol "WB_RESISTOR" attribute "TOL" references missing text style ""
Warning: Symbol "WB_RESISTOR" attribute "RefDes2" references missing text style ""
Warning: Symbol "WB_CAP_POLARIZED" attribute "PN" references missing text style ""
Warning: Symbol "WB_CAP_POLARIZED" attribute "DEV" references missing text style ""
Warning: Symbol "WB_CAP_POLARIZED" attribute "VAL" references missing text style ""
Warning: Symbol "WB_CAP_POLARIZED" attribute "TOL" references missing text style ""
Warning: Symbol "WB_CAP_POLARIZED" attribute "RefDes2" references missing text style ""
Warning: Symbol "WB_CAPACITOR" attribute "PN" references missing text style ""
Warning: Symbol "WB_CAPACITOR" attribute "DEV" references missing text style ""
Warning: Symbol "WB_CAPACITOR" attribute "VAL" references missing text style ""
Warning: Symbol "WB_CAPACITOR" attribute "TOL" references missing text style ""
Warning: Symbol "WB_CAPACITOR" attribute "RefDes2" references missing text style ""
Warning: Symbol "WB_RESISTOR" attribute "PN" references missing text style ""
Warning: Symbol "WB_RESISTOR" attribute "DEV" references missing text style ""
Warning: Symbol "WB_RESISTOR" attribute "VAL" references missing text style ""
Warning: Symbol "WB_RESISTOR" attribute "TOL" references missing text style ""
Warning: Symbol "WB_RESISTOR" attribute "RefDes2" references missing text style ""
Warning: Symbol "WB_CAPACITOR" attribute "PN" references missing text style ""
Warning: Symbol "WB_CAPACITOR" attribute "DEV" references missing text style ""
Warning: Symbol "WB_CAPACITOR" attribute "VAL" references missing text style ""
Warning: Symbol "WB_CAPACITOR" attribute "TOL" references missing text style ""
Warning: Symbol "WB_CAPACITOR" attribute "RefDes2" references missing text style ""
Warning: Symbol "WB_CAPACITOR" attribute "PN" references missing text style ""
Warning: Symbol "WB_CAPACITOR" attribute "DEV" references missing text style ""
Warning: Symbol "WB_CAPACITOR" attribute "VAL" references missing text style ""
Warning: Symbol "WB_CAPACITOR" attribute "TOL" references missing text style ""
Warning: Symbol "WB_CAPACITOR" attribute "RefDes2" references missing text style ""
Warning: Symbol "WB_RESISTOR" attribute "PN" references missing text style ""
Warning: Symbol "WB_RESISTOR" attribute "DEV" references missing text style ""
Warning: Symbol "WB_RESISTOR" attribute "VAL" references missing text style ""
Warning: Symbol "WB_RESISTOR" attribute "TOL" references missing text style ""
Warning: Symbol "WB_RESISTOR" attribute "RefDes2" references missing text style ""
Warning: Symbol "WB_CAPACITOR" attribute "PN" references missing text style ""
Warning: Symbol "WB_CAPACITOR" attribute "DEV" references missing text style ""
Warning: Symbol "WB_CAPACITOR" attribute "VAL" references missing text style ""
Warning: Symbol "WB_CAPACITOR" attribute "TOL" references missing text style ""
Warning: Symbol "WB_CAPACITOR" attribute "RefDes2" references missing text style ""
Warning: Symbol "TPS54561DPRR" attribute "TOL" references missing text style ""
Warning: Symbol "TPS54561DPRR" attribute "VAL" references missing text style ""
Warning: Symbol "TPS54561DPRR" attribute "DEV" references missing text style ""
Warning: Symbol "TPS54561DPRR" attribute "PN" references missing text style ""
Warning: Symbol "WB_INDUCTOR" attribute "PN" references missing text style ""
Warning: Symbol "WB_INDUCTOR" attribute "DEV" references missing text style ""
Warning: Symbol "WB_INDUCTOR" attribute "VAL" references missing text style ""
Warning: Symbol "WB_INDUCTOR" attribute "TOL" references missing text style ""
Warning: Symbol "WB_INDUCTOR" attribute "RefDes2" references missing text style ""
Warning: Symbol "WB_DIODE_SCHOTTK" attribute "PN" references missing text style ""
Warning: Symbol "WB_DIODE_SCHOTTK" attribute "DEV" references missing text style ""
Warning: Symbol "WB_DIODE_SCHOTTK" attribute "VAL" references missing text style ""
Warning: Symbol "WB_DIODE_SCHOTTK" attribute "TOL" references missing text style ""
Warning: Symbol "WB_DIODE_SCHOTTK" attribute "RefDes2" references missing text style ""
Warning: Symbol "WB_RESISTOR" attribute "PN" references missing text style ""
Warning: Symbol "WB_RESISTOR" attribute "DEV" references missing text style ""
Warning: Symbol "WB_RESISTOR" attribute "VAL" references missing text style ""
Warning: Symbol "WB_RESISTOR" attribute "TOL" references missing text style ""
Warning: Symbol "WB_RESISTOR" attribute "RefDes2" references missing text style ""
Warning: Symbol "WB_CAPACITOR" attribute "PN" references missing text style ""
Warning: Symbol "WB_CAPACITOR" attribute "DEV" references missing text style ""
Warning: Symbol "WB_CAPACITOR" attribute "VAL" references missing text style ""
Warning: Symbol "WB_CAPACITOR" attribute "TOL" references missing text style ""
Warning: Symbol "WB_CAPACITOR" attribute "RefDes2" references missing text style ""
